AGBR-Net RGB/LiDAR Evaluation — Stage 1

What is done:
1. Read ROS2 /scan LaserScan messages from all five scenes.
2. Identified the camera-facing LiDAR sector empirically: the introduced boxes in scenes 2-4 occur near the ±180-degree wrap, so camera forward is treated as LiDAR 180 degrees for this first alignment.
3. Used an approximate iPhone 17 1x horizontal FOV of 69.39 degrees, derived from Apple's 26 mm-equivalent main-camera specification.
4. Reduced each stationary recording to median LiDAR distance by 1-degree angular bin.
5. Projected those angular bins to approximate RGB horizontal pixel coordinates.

Important:
- This is an approximate evaluation alignment, not a formal camera-LiDAR calibration.
- The white horizontal line in each preview is the nominal scan plane. Camera pitch can move the true scan plane vertically.
- LiDAR should be reported as sparse external reference measurements, not a full ground-truth depth image.
- Scene 5 shows weaker correspondence than scenes 2-4 and should be treated cautiously until the pairing/setup is verified.

Next stage:
Run each RGB image through the existing AGBR-Net pipeline and save raw MiDaS depth plus final GAN-refined depth. Then fit monocular relative depth to LiDAR reference samples and compare errors before vs after refinement.
